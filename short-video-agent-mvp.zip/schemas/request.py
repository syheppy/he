from pydantic import BaseModel

class VideoRequest(BaseModel):
    topic: str
    platform: str = "抖音"
    target_user: str = "18-35岁用户"
    style: str = "爆款传播感"
