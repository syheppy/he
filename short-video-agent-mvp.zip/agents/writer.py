from agents.base import call_llm

def script_writer_agent(data, trend_output):
    return call_llm(
        "你是脚本专家，请生成爆款短视频脚本。",
        f"主题：{data.topic}\n热点分析：{trend_output}"
    )
