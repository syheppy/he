from agents.base import call_llm

def title_agent(data, script_output):
    return call_llm(
        "你是标题专家，请生成10个爆款标题。",
        f"主题：{data.topic}\n脚本：{script_output}"
    )
