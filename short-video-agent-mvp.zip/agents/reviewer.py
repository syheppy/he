from agents.base import call_llm

def reviewer_agent(script_output, title_output):
    return call_llm(
        "你是审核优化Agent，请优化内容传播效果。",
        f"脚本：{script_output}\n标题：{title_output}"
    )
