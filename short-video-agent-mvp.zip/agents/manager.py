from agents.base import call_llm

def manager_agent(data):
    return call_llm(
        "你是Manager Agent，负责拆解短视频爆款策略。",
        f"主题：{data.topic}，平台：{data.platform}"
    )
