from agents.base import call_llm

def trend_agent(data, manager_output):
    return call_llm(
        "你是热点分析Agent，负责分析用户停留点和互动点。",
        f"主题：{data.topic}\n策略：{manager_output}"
    )
